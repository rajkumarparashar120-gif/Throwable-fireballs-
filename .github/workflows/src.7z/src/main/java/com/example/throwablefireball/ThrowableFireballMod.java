package com.example.throwablefireball;

import net.fabricmc.api.ModInitializer;

public class ThrowableFireballMod implements ModInitializer {
    public static final String MOD_ID = "throwablefireball";

    @Override
    public void onInitialize() {
        ModItems.registerItems();
    }
}
