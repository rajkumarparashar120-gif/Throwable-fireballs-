package com.example.throwablefireball;

import com.example.throwablefireball.entity.CustomFireballEntity;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ModItems {
    public static final Item FIREBALL_STAFF = new Item(new FabricItemSettings().maxCount(1)) {
        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!world.isClient) {
                CustomFireballEntity fireball = new CustomFireballEntity(world, user);
                Vec3d look = user.getRotationVec(1.0F);
                fireball.setVelocity(look.x, look.y, look.z, 1.5F, 0);
                world.spawnEntity(fireball);
            }
            return TypedActionResult.success(user.getStackInHand(hand));
        }
    };

    public static void registerItems() {
        Registry.register(Registries.ITEM, new Identifier(ThrowableFireballMod.MOD_ID, "fireball_staff"), FIREBALL_STAFF);
    }
}
