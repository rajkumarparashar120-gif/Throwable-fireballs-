package com.example.throwablefireball.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.world.World;

public class CustomFireballEntity extends FireballEntity {
    public CustomFireballEntity(EntityType<? extends FireballEntity> entityType, World world) {
        super(entityType, world);
    }

    public CustomFireballEntity(World world, LivingEntity owner) {
        super(EntityType.FIREBALL, owner, 0, 0, 0, world);
    }
}
